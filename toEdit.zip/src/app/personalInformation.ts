export interface PersonalInformation{

    customerId : number;
    customerName: string ;
    customerEmail: string ;
    customerPassword: string ;
    customerPhoneNumber: string ;
    customerAddress: string ;
    customerCity: string ;
    customerZip: string ;
    customerCountry: string ;
    customerBalance: number;
  }