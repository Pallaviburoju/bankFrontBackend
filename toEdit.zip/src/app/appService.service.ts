import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { FourthComponent } from './fourth/fourth.component';
import { PersonalInformation } from './personalInformation';

@Injectable({
  providedIn: 'root'
})

export class AppServiceService {
  //url = 'http://localhost:8909/get'
  url2 = 'http://localhost:8909/register'
  url3 = 'http://localhost:8909/login'
  url4 = 'http://localhost:8909/showbalance'
  url5 = 'http://localhost:8909/deposit'
   constructor(private httpService : HttpClient){ }

  //  public getData(): Observable<any>{
  //     return this.httpService.get(this.url);
  //  }
  
   public sendData( user ){
    return this.httpService.post<PersonalInformation>(this.url2, user);
   }

   public login(logindata): Observable<any>{
    return this.httpService.post(this.url3, logindata)
   }

   public showbalance(): Observable<any>{
     return this.httpService.get(this.url4);
   }

   public deposit(amount):Observable<any>{
     return this.httpService.put(this.url5, amount);
   }
}
