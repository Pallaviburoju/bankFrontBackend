export interface TransactionDetails{
    transactionId : number;
    fromAcc : number;
    toAcc : number;
    amt : number;
}