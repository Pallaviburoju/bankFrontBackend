import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppServiceService } from '../appService.service';
import { TransactionDetails } from '../TransactionDetails';
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {

  constructor(private router: Router, private service: AppServiceService) { }

  ngOnInit() {
  }

  transactionDetails : TransactionDetails = {
    transactionId : 0,
    fromAcc : 0,
    toAcc : 0,
    amt : 0
  }
 
}
